/**
 * TESO System Color Palette
 * Standardized colors for the 3x3 grid interface.
 */
/**
 * TESO System Color Palette
 * Standardized colors for the 3x3 grid interface.
 */
export const TESO_COLORS = {
  1: 'bg-white text-black',
  2: 'bg-[#F5E6AB] text-black',
  3: 'bg-[#FFB3FF] text-black',
  4: 'bg-[#FFFF00] text-black',
  5: 'bg-[#228B22] text-white',
  6: 'bg-[#0044FF] text-white',
  7: 'bg-[#633F1B] text-white',
  8: 'bg-[#666666] text-white',
  9: 'bg-black text-white border border-white/20',
} as const;

export const TESO_COLOR_INDICATORS = {
  1: { bg: 'bg-white' },
  2: { bg: 'bg-[#F5E6AB]' },
  3: { bg: 'bg-[#FFB3FF]' },
  4: { bg: 'bg-[#FFFF00]' },
  5: { bg: 'bg-[#228B22]' },
  6: { bg: 'bg-[#0044FF]' },
  7: { bg: 'bg-[#633F1B]' },
  8: { bg: 'bg-[#666666]' },
  9: { bg: 'bg-black' },
} as const;

export type TesoColorKey = keyof typeof TESO_COLORS;

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  PlusCircle, 
  SlidersHorizontal, 
  MessageSquareMore, 
  Volume2, 
  Mic, 
  Play, 
  Pause, 
  RotateCcw, 
  RotateCw, 
  X, 
  Maximize2, 
  Loader2,
  Mail,
  Smartphone,
  Cloud,
  Share2,
  MessageCircle,
  Send,
  Slack,
  Globe,
  UploadCloud,
  ArrowDown,
  ArrowUp
} from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { useLayerId } from '../contexts/LayerContext';
import { TESO_COLORS } from '../constants';
import { useLongPress } from '../hooks/useLongPress';

interface TesoHostingProps {
  onBack: () => void;
  onGoLanding: () => void;
  onOpenIA: () => void;
  onOpenConfiguracion?: () => void;
  onAdd?: () => void;
  layerId: string;
  showPulsor?: boolean;
  className?: string;
  children?: React.ReactNode;
}

export default function TesoHosting({ 
  onBack, 
  onGoLanding, 
  onOpenIA, 
  onOpenConfiguracion, 
  onAdd,
  layerId,
  showPulsor = false,
  className = "mt-auto",
  children
}: TesoHostingProps) {
  const { 
    configMode, 
    setConfigMode, 
    setLayerSetting, 
    getLayerSettings, 
    motherHostingFontSize, 
    motherHostingIconSize,
    motherHostingShowText,
    motherHostingShowIcons,
    setMotherHostingFontSize,
    setMotherHostingIconSize,
    setMotherHostingShowIcons,
    setMotherHostingShowText,
    resetLayerSettings,
    isHostingVisible,
    setIsHostingVisible
  } = useSettings();
  const [isListening, setIsListening] = useState(false);
  const [showPlayBar, setShowPlayBar] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [playBarScale, setPlayBarScale] = useState(1);
  const [showCommLayer, setShowCommLayer] = useState(false);
  
  const layerSettings = getLayerSettings(layerId);
  const currentFontSize = layerSettings.fontSize ?? motherHostingFontSize;
  const currentIconSize = layerSettings.iconSize ?? motherHostingIconSize;
  const currentShowText = layerSettings.showText ?? motherHostingShowText;
  const currentShowIcons = layerSettings.showIcons ?? motherHostingShowIcons;

  const longPressBack = useLongPress({
    onShortPress: () => {
      if (configMode !== 'none') {
        setConfigMode('none');
      } else {
        onBack();
      }
    },
    onLongPress: onGoLanding,
    longPressThreshold: 500,
  });

  const handleNumericClick = (num: number) => {
    if (showPlayBar) {
      const newSpeed = 1 + (num - 1) * 0.1875;
      setPlaybackSpeed(newSpeed);
      return;
    }

    if (configMode === 'text') {
      const newSize = 8 + (num - 1) * 2;
      if (layerId) {
        setLayerSetting(layerId, 'fontSize', newSize);
      } else {
        setMotherHostingFontSize(newSize);
      }
    } else if (configMode === 'icons') {
      const newSize = 32 + (num - 1) * 8;
      if (layerId) {
        setLayerSetting(layerId, 'iconSize', newSize);
      } else {
        setMotherHostingIconSize(newSize);
      }
    }
  };

  const getMenuLabel = (num: number) => {
    return num.toString();
  };

  const commButtons = [
    { id: 1, label: 'E-MAIL', icon: <Mail className="w-8 h-8" /> },
    { id: 2, label: 'SMS', icon: <Smartphone className="w-8 h-8" /> },
    { id: 3, label: 'NUBE', icon: <UploadCloud className="w-8 h-8" /> },
    { id: 4, label: 'REDES', icon: <Share2 className="w-8 h-8" /> },
    { id: 5, label: 'WHATSAPP', icon: <MessageCircle className="w-8 h-8" /> },
    { id: 6, label: 'TELEGRAM', icon: <Send className="w-8 h-8" /> },
    { id: 7, label: 'SLACK', icon: <Slack className="w-8 h-8" /> },
    { id: 8, label: 'WEB', icon: <Globe className="w-8 h-8" /> },
    { id: 9, label: 'TESO', icon: <Loader2 className="w-8 h-8" /> },
  ];

  const activeNum = showPlayBar
    ? Math.round((playbackSpeed - 1) / 0.1875) + 1
    : configMode === 'text' 
      ? Math.round((currentFontSize - 8) / 2) + 1 
      : configMode === 'icons' 
        ? Math.round((currentIconSize - 32) / 8) + 1 
        : null;

  return (
    <div className={`z-50 flex flex-col items-end gap-3 pointer-events-none shrink-0 ${className}`}>
      
      {/* Show Hosting Button (Floating at bottom right when hidden) */}
      <AnimatePresence>
        {!isHostingVisible && (
          <motion.button
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: 20 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsHostingVisible(true)}
            className="fixed bottom-5 right-5 w-14 h-14 bg-gradient-to-br from-[#4A3018] to-[#1A0F05] border border-[#D4AF37]/50 shadow-[0_0_15px_rgba(212,175,55,0.4)] rounded-lg flex items-center justify-center pointer-events-auto z-[60]"
          >
            <svg className="w-8 h-8 text-[#D4AF37]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M18 6v8M18 6H10" />
            </svg>
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isHostingVisible && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="flex flex-col items-end gap-3"
          >
            {/* Pulsor Giratorio (Spinning Indicator) */}
            {showPulsor && (
              <div className="absolute top-[-300px] left-[-300px] pointer-events-none">
                <div className="w-16 h-16 rounded-full border-[2.5px] border-[#FFD700] shadow-[0_0_20px_rgba(255,215,0,0.8),inset_0_0_15px_rgba(255,215,0,0.5)] flex items-center justify-center bg-transparent relative">
                  <div className="absolute inset-[-5px] rounded-full border-[2px] border-dashed border-[#FFD700] animate-[spin_6s_linear_infinite]" />
                  <div className="absolute inset-[4px] rounded-full border-[2px] border-[#FFD700] animate-[spin_4s_linear_infinite_reverse]" style={{ borderTopColor: 'transparent' }} />
                  <div className="w-2 h-2 rounded-full bg-[#FFD700] shadow-[0_0_12px_rgba(255,215,0,1)]" />
                </div>
              </div>
            )}

            {/* Communication Layer Overlay */}
            <AnimatePresence>
              {showCommLayer && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 20 }}
                  className="bg-neutral-900/95 border border-orange-500/30 rounded-2xl p-4 shadow-2xl backdrop-blur-xl pointer-events-auto mb-2"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-orange-500 font-black tracking-widest text-xs uppercase">Comunicación</h3>
                    <button onClick={() => setShowCommLayer(false)} className="text-white/40 hover:text-white">
                      <X size={16} />
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {commButtons.map((btn) => (
                      <motion.button
                        key={btn.id}
                        whileTap={{ scale: 0.9 }}
                        className="w-16 h-16 bg-gradient-to-br from-amber-700/20 to-orange-950/40 border border-orange-500/20 rounded-xl flex flex-col items-center justify-center gap-1 hover:bg-orange-500/20 transition-colors"
                      >
                        <div className="text-orange-400">{btn.icon}</div>
                        <span className="text-[8px] font-black text-white/60">{btn.label}</span>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-3 items-end">
              {/* Play Bar */}
              <AnimatePresence>
                {showPlayBar && (
                  <motion.div 
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1, scale: playBarScale }}
                    exit={{ x: -20, opacity: 0 }}
                    className="bg-neutral-900/95 border border-white/20 rounded-xl p-2 flex flex-col items-center gap-3 shadow-2xl backdrop-blur-md shrink-0 pointer-events-auto"
                  >
                    <motion.button 
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="w-9 h-9 bg-white text-black rounded-lg flex items-center justify-center shadow-lg"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" fill="currentColor" /> : <Play className="w-4 h-4 ml-0.5" fill="currentColor" />}
                    </motion.button>
                    <div className="flex flex-col w-full items-center px-0.5">
                      <span className="text-[9px] font-black text-white leading-none">0:00</span>
                      <span className="text-[8px] font-bold text-yellow-500 leading-none mt-1">{playbackSpeed.toFixed(2)}x</span>
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <motion.button whileTap={{ scale: 0.9 }} className="w-8 h-8 bg-white/5 text-white rounded-md flex items-center justify-center border border-white/5"><RotateCcw size={14} /></motion.button>
                      <motion.button whileTap={{ scale: 0.9 }} className="w-8 h-8 bg-white/5 text-white rounded-md flex items-center justify-center border border-white/5"><RotateCw size={14} /></motion.button>
                    </div>
                    <motion.button 
                      whileTap={{ scale: 0.9 }} 
                      onClick={() => setPlayBarScale(prev => prev === 1 ? 1.3 : 1)}
                      className="w-8 h-8 bg-yellow-500/10 text-yellow-500 rounded-md flex items-center justify-center border border-yellow-500/10"
                    >
                      <Maximize2 size={14} />
                    </motion.button>
                    <motion.button 
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setShowPlayBar(false)}
                      className="w-8 h-8 bg-red-500/10 text-red-500 rounded-md flex items-center justify-center border border-red-500/10"
                    >
                      <X size={14} />
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Main Interaction Section */}
              <section className="flex flex-col items-end gap-2 pointer-events-auto">
                {/* Top Row */}
                <div className="flex gap-2">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setShowPlayBar(!showPlayBar)}
                    className="w-14 h-14 bg-gradient-to-br from-blue-400 via-blue-600 to-blue-800 text-white rounded-lg flex items-center justify-center shadow-md border border-blue-400/50"
                  >
                    <Volume2 className="w-8 h-8" strokeWidth={2.5} />
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsListening(!isListening)}
                    className={`w-14 h-14 rounded-lg flex items-center justify-center shadow-md border transition-all ${
                      isListening ? 'bg-red-500 animate-pulse border-red-400' : 'bg-gradient-to-br from-indigo-400 via-indigo-600 to-indigo-800 text-white border-indigo-400/50'
                    }`}
                  >
                    <Mic className="w-8 h-8" strokeWidth={2.5} />
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={onOpenIA}
                    className="w-14 h-14 bg-gradient-to-br from-yellow-200 via-yellow-500 to-yellow-700 text-yellow-950 rounded-lg flex items-center justify-center font-black text-xl shadow-md border border-yellow-300/50"
                  >
                    IA
                  </motion.button>
                  
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    {...longPressBack}
                    className={`w-14 h-14 rounded-lg flex items-center justify-center shadow-md border transition-colors ${
                      configMode !== 'none' ? 'bg-gradient-to-br from-red-400 via-red-600 to-red-800 text-white border-red-400/50' : 'bg-gradient-to-br from-slate-100 via-slate-300 to-slate-500 text-slate-900 border-slate-200/50'
                    }`}
                  >
                    <ArrowLeft className="w-8 h-8" strokeWidth={2.5} />
                  </motion.button>
                </div>

                {/* Bottom Grid Area */}
                <div className="flex gap-2 items-start">
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-end">
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => {
                          if (configMode !== 'none') {
                            setConfigMode('none');
                          } else if (onOpenConfiguracion) {
                            onOpenConfiguracion();
                          } else {
                            setConfigMode('text');
                          }
                        }}
                        className={`w-14 h-14 rounded-lg flex items-center justify-center shadow-md border transition-all ${
                          configMode !== 'none' ? 'bg-white text-black border-white ring-4 ring-white/20' : 'bg-gradient-to-br from-orange-800 via-orange-950 to-neutral-950 text-orange-200 border-orange-800/50'
                        }`}
                      >
                        <SlidersHorizontal className="w-8 h-8" strokeWidth={2.5} />
                      </motion.button>
                    </div>

                    <div className="flex justify-end">
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={onAdd}
                        className="bg-gradient-to-br from-zinc-500 via-zinc-700 to-zinc-900 text-zinc-100 w-14 h-14 rounded-lg flex items-center justify-center shadow-md border border-zinc-400/50"
                      >
                        <PlusCircle className="w-8 h-8" strokeWidth={2.5} />
                      </motion.button>
                    </div>

                    <div className="flex gap-2">
                      {/* Close Hosting Button */}
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setIsHostingVisible(false)}
                        className="bg-gradient-to-br from-neutral-700 via-neutral-800 to-neutral-950 text-[#D4AF37] w-14 h-14 rounded-lg flex items-center justify-center shadow-md border border-white/10"
                      >
                        <svg className="w-8 h-8 text-[#D4AF37]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M18 6L6 18M6 18V10M6 18H14" />
                        </svg>
                      </motion.button>

                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setShowCommLayer(!showCommLayer)}
                        className="bg-gradient-to-br from-amber-700 via-orange-800 to-orange-950 text-orange-100 w-14 h-14 rounded-lg flex items-center justify-center shadow-md border border-orange-500/50"
                      >
                        <MessageSquareMore className="w-8 h-8" strokeWidth={2.5} />
                      </motion.button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 w-[184px] h-[184px] relative">
                    {configMode !== 'none' || showPlayBar || !children ? (
                      [1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                        <motion.button
                          key={num}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleNumericClick(num)}
                          className={`${TESO_COLORS[num as keyof typeof TESO_COLORS]} w-14 h-14 rounded-lg flex items-center justify-center text-xl font-black border border-white/5 shadow-sm transition-all ${
                            configMode !== 'none' ? (num === activeNum ? 'ring-4 ring-white scale-110 z-10 shadow-[0_0_20px_rgba(255,255,255,0.4)]' : 'opacity-40 scale-90') : ''
                          }`}
                        >
                          <span className="text-center leading-none" style={{ fontSize: '16px' }}>
                            {getMenuLabel(num)}
                          </span>
                        </motion.button>
                      ))
                    ) : (
                      children
                    )}
                  </div>
                </div>
              </section>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Map as MapIcon, Info } from 'lucide-react';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { MapHostingButtons } from './MapHostingButtons';
import { useSettings } from '../contexts/SettingsContext';

interface PlanoEmpresaPageProps {
  onBack: () => void;
  onGoLanding: () => void;
  onOpenIA: () => void;
  onOpenConfiguracion?: () => void;
}

export default function PlanoEmpresaPage({ onBack, onGoLanding, onOpenIA, onOpenConfiguracion }: PlanoEmpresaPageProps) {
  const { isHostingVisible } = useSettings();
  const [selectedZone, setSelectedZone] = React.useState<string | null>(null);

  const zones = [
    { id: 'acceso', label: 'ACCESO', x: 50, y: 500, w: 100, h: 60, color: 'bg-blue-500/20' },
    { id: 'oficinas', label: 'OFICINAS', x: 50, y: 300, w: 200, h: 180, color: 'bg-indigo-500/20' },
    { id: 'produccion', label: 'PRODUCCIÓN', x: 270, y: 100, w: 400, h: 300, color: 'bg-red-500/20' },
    { id: 'almacen', label: 'ALMACÉN', x: 270, y: 420, w: 250, h: 140, color: 'bg-amber-500/20' },
    { id: 'carga', label: 'CARGA', x: 540, y: 420, w: 130, h: 140, color: 'bg-orange-500/20' },
    { id: 'exterior', label: 'EXTERIOR', x: 0, y: 0, w: 800, h: 600, color: 'bg-emerald-500/5', isBackground: true },
    { id: 'comunes', label: 'ZONAS COMUNES', x: 50, y: 100, w: 200, h: 180, color: 'bg-teal-500/20' },
    { id: 'vestuarios', label: 'VESTUARIOS', x: 690, y: 100, w: 90, h: 150, color: 'bg-pink-500/20' },
    { id: 'tecnica', label: 'SALA TÉCNICA', x: 690, y: 270, w: 90, h: 130, color: 'bg-slate-500/20' },
  ];

  if (selectedZone) {
    return (
      <div className="min-h-screen w-full bg-neutral-950 flex flex-col items-center justify-center relative overflow-hidden p-4 sm:p-6">
        <div className="w-full max-w-4xl mb-6 flex justify-between items-center z-10">
          <button onClick={() => setSelectedZone(null)} className="text-white flex items-center gap-2">
            <ArrowLeft size={24} />
            <span className="text-xl font-black uppercase">Volver al Plano</span>
          </button>
          <h1 className="text-2xl font-black text-white uppercase italic">{selectedZone}</h1>
        </div>
        <div className="relative w-full max-w-4xl aspect-[4/3] bg-neutral-900 border border-white/10 rounded-3xl shadow-2xl overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center text-white">
            Detalle de {selectedZone}
          </div>
        </div>
        <MapHostingButtons
          onBack={() => setSelectedZone(null)}
          onOpenIA={onOpenIA}
          isHostingVisible={isHostingVisible}
          setIsHostingVisible={() => {}}
          onPan={(dx, dy) => console.log('Pan:', dx, dy)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-neutral-950 flex flex-col items-center justify-center relative overflow-hidden p-4 sm:p-6">
      {/* Header */}
      <div className={`w-full max-w-4xl mb-6 flex justify-between items-center z-10 transition-all duration-500 ${isHostingVisible ? 'opacity-100' : 'opacity-40 scale-90'}`}>
        <div className="flex flex-col">
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tighter uppercase italic">PLANO EMPRESA</h1>
          <span className="text-[10px] sm:text-[12px] font-bold text-emerald-500 tracking-[0.3em] -mt-1">SYSTEM / MAPS</span>
        </div>
        <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10 backdrop-blur-md">
          <MapIcon size={16} className="text-emerald-500" />
          <span className="text-[10px] font-black text-white/80 tracking-widest uppercase">Vista Planta</span>
        </div>
      </div>

      {/* Map Container */}
      <div className={`relative w-full max-w-4xl aspect-[4/3] bg-neutral-900 border border-white/10 rounded-3xl shadow-2xl overflow-hidden transition-all duration-500 ${isHostingVisible ? 'mb-24' : 'scale-110 mb-0'}`}>
        <TransformWrapper initialScale={1} minScale={0.5} maxScale={4}>
          <TransformComponent wrapperStyle={{ width: '100%', height: '100%' }} contentStyle={{ width: '100%', height: '100%' }}>
            {/* Grid Background */}
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
            
            {/* Zones Container (Responsive scaling) */}
            <div className="absolute inset-0 origin-top-left" style={{ transform: 'scale(var(--map-scale, 1))' }}>
              {zones.map((zone) => (
                <motion.div
                  key={zone.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
                  onClick={() => setSelectedZone(zone.label)}
                  className={`absolute border border-white/10 flex items-center justify-center transition-colors cursor-pointer group ${zone.color} ${zone.isBackground ? '-z-10' : 'z-0'}`}
                  style={{
                    left: `${(zone.x / 800) * 100}%`,
                    top: `${(zone.y / 600) * 100}%`,
                    width: `${(zone.w / 800) * 100}%`,
                    height: `${(zone.h / 600) * 100}%`,
                    borderRadius: zone.isBackground ? '0' : '12px'
                  }}
                >
                  {!zone.isBackground && (
                    <div className="flex flex-col items-center gap-1">
                      <span className="text-[8px] sm:text-[10px] font-black text-white/80 tracking-tighter text-center px-2 leading-none group-hover:text-white transition-colors">
                        {zone.label}
                      </span>
                      <div className="w-4 h-0.5 bg-white/20 group-hover:bg-white/60 transition-colors" />
                    </div>
                  )}
                  {zone.id === 'exterior' && (
                    <span className="absolute top-4 left-4 text-[8px] sm:text-[10px] font-black text-emerald-500/40 tracking-widest uppercase">Perímetro Exterior</span>
                  )}
                </motion.div>
              ))}
            </div>
          </TransformComponent>
        </TransformWrapper>

        {/* Legend / Info */}
        <div className={`absolute bottom-4 left-4 sm:bottom-6 sm:left-6 bg-black/60 backdrop-blur-md border border-white/10 p-3 sm:p-4 rounded-xl flex items-start gap-3 max-w-[160px] sm:max-w-[200px] transition-all duration-500 ${isHostingVisible ? 'opacity-100' : 'opacity-0 scale-75'}`}>
          <Info className="text-blue-400 shrink-0" size={16} />
          <p className="text-[8px] sm:text-[9px] text-white/60 font-medium leading-relaxed">
            Plano interactivo de instalaciones. Pulsa en una zona para ver detalles de seguridad y sensores activos.
          </p>
        </div>

        {/* Compass */}
        <div className="absolute top-4 right-4 sm:top-6 sm:right-6 flex flex-col items-center opacity-40">
          <div className="w-6 h-6 sm:w-8 sm:h-8 border-2 border-white rounded-full flex items-center justify-center relative">
            <div className="w-0.5 h-3 sm:h-4 bg-red-500 absolute top-0" />
            <span className="text-[7px] sm:text-[8px] font-black text-white absolute -top-4">N</span>
          </div>
        </div>
      </div>

      {/* Hosting Buttons */}
      <MapHostingButtons
        onBack={onBack}
        onOpenIA={onOpenIA}
        isHostingVisible={isHostingVisible}
        setIsHostingVisible={() => {}}
        onPan={(dx, dy) => console.log('Pan:', dx, dy)}
      />

      {/* Background Decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1200px] h-[1200px] bg-blue-500/5 rounded-full blur-[150px] -z-20" />
    </div>
  );
}
